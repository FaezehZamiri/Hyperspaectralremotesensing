clc
clear
close all
load('data/data1.mat')
load('data/F2.mat')
[ID X Y]=textread('data/F2.txt','%f%f%f');
t=[X,Y];

% Demonstrate difference spectral similarity measurements
[h, w, p] = size(M);
target=sig1;
figure; plot(target); grid on; title('Target Signature');

M = hyperConvert2d(M);
  
% RX Anomly Detector
r = hyperRxDetector(M);
r = hyperConvert3d(r.', h, w, 1);
figure; imagesc(r); title('RX Detector Results'); axis image;colorbar;

% Constrained Energy Minimization (CEM)
rCEM = hyperCem(M, target);
rCEM2 = hyperConvert3d(rCEM, h, w, 1);
figure; imagesc(abs(rCEM2)); title('CEM Detector Results'); axis image;colorbar;    

% Adaptive Cosine Estimator (ACE)
rACE = hyperAce(M, target);
rACE2 = hyperConvert3d(rACE, h, w, 1);
figure; imagesc(rACE2); title('ACE Detector Results'); axis image;colorbar;   

% Signed Adaptive Cosine Estimator (S-ACE)
rSACE = hyperSignedAce(M, target);
rSACE2 = hyperConvert3d(rSACE, h, w, 1);
figure; imagesc(rSACE2); title('Signed ACE Detector Results'); axis image;colorbar; 

% Matched Filter
rMF = hyperMatchedFilter(M, target);
rMF2 = hyperConvert3d(rMF, h, w, 1);
figure; imagesc(rMF2); title('MF Detector Results'); axis image;colorbar; 

% Generalized Likehood Ratio Test (GLRT) detector
rGLRT = hyperGlrt(M, target);
rGLRT2 = hyperConvert3d(rGLRT, h, w, 1);
figure; imagesc(rGLRT2); title('GLRT Detector Results'); axis image;colorbar;


% Estimate background endmembers
[q] = 19
U3= hyperAtgp(M, q);
U1=Uppi;
U=Unfindr;
U2=Uvca;

% Adaptive Matched Subspace Detector (AMSD)
rAMSD = hyperAmsd(M, U, target);
rAMSD2 = hyperConvert3d(rAMSD, h, w, 1);
figure; imagesc(abs(rAMSD2)); title('AMSD Detector Results'); axis image;colorbar;
figure; mesh(rAMSD2); title('AMSD Detector Results');

% Orthogonal Subspace Projection (OSP)
rOSP = hyperOsp(M, U, target);
rOSP2 = hyperConvert3d(rOSP, h, w, 1);
figure; imagesc(abs(rOSP2)); title('OSP Detector Results'); axis image;colorbar;   


% Threshold
[counts,x] = imhist(rOSP,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rOSP,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('OSP Detector Results');
%
[counts,x] = imhist(rAMSD,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rAMSD,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('AMSD Detector Results');

%11
% Adaptive Matched Subspace Detector (AMSD)
rAMSD01 = hyperAmsd(M, U1, target);
rAMSD02 = hyperConvert3d(rAMSD01, h, w, 1);
figure; imagesc(abs(rAMSD02)); title('AMSD Detector Results'); axis image;colorbar;
figure; mesh(rAMSD02); title('AMSD Detector Results');

% Orthogonal Subspace Projection (OSP)
rOSP01 = hyperOsp(M, U1, target);
rOSP02 = hyperConvert3d(rOSP01, h, w, 1);
figure; imagesc(abs(rOSP02)); title('OSP Detector Results'); axis image;colorbar;   


% Threshold
[counts,x] = imhist(rOSP01,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rOSP01,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('OSP Detector Results');
%
[counts,x] = imhist(rAMSD01,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rAMSD01,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('AMSD Detector Results');
%22
% Adaptive Matched Subspace Detector (AMSD)
rAMSD022 = hyperAmsd(M, U2, target);
rAMSD023 = hyperConvert3d(rAMSD022, h, w, 1);
figure; imagesc(abs(rAMSD2)); title('AMSD Detector Results'); axis image;colorbar;
figure; mesh(rAMSD023); title('AMSD Detector Results');

% Orthogonal Subspace Projection (OSP)
rOSP022 = hyperOsp(M, U2, target);
rOSP023 = hyperConvert3d(rOSP022, h, w, 1);
figure; imagesc(abs(rOSP023)); title('OSP Detector Results'); axis image;colorbar;   


% Threshold
[counts,x] = imhist(rOSP022,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rOSP022,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('OSP Detector Results');

[counts,x] = imhist(rAMSD022,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rAMSD022,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('AMSD Detector Results');

%33
% Adaptive Matched Subspace Detector (AMSD)
rAMSD3 = hyperAmsd(M, U3, target);
rAMSD32 = hyperConvert3d(rAMSD3, h, w, 1);
figure; imagesc(abs(rAMSD32)); title('AMSD Detector Results'); axis image;colorbar;
figure; mesh(rAMSD32); title('AMSD Detector Results');

% Orthogonal Subspace Projection (OSP)
rOSP3 = hyperOsp(M, U3, target);
rOSP32 = hyperConvert3d(rOSP3, h, w, 1);
figure; imagesc(abs(rOSP32)); title('OSP Detector Results'); axis image;colorbar;   


% Threshold
[counts,x] = imhist(rOSP3,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rOSP3,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('OSP Detector Results');
%
[counts,x] = imhist(rAMSD3,224000);
stem(x,counts)
T = otsuthresh(counts)
BW = imbinarize(rAMSD3,T);
BW = hyperConvert3d(BW, h, w, 1);
figure;imagesc(BW); title('AMSD Detector Results');

%ROC
% [AUC1,FPR1,TPR1]=hyperRoc(rCEM,t);
% figure;plot(FPR1,TPR1,'^-')
% hold on
% 
% [AUC2,FPR2,TPR2]=hyperRoc(rACE,t);
% plot(FPR2,TPR2,'*-')
% 
% hold on
% [AUC3,FPR3,TPR3]=hyperRoc(rSACE,t);
% plot(FPR3,TPR3,'o-')
% 
% [AUC4,FPR4,TPR4]=hyperRoc(rMF,t);
% plot(FPR4,TPR4,'v-')
% 
% [AUC5,FPR5,TPR5]=hyperRoc(rGLRT,t);
% plot(FPR5,TPR5,'>-')

[AUC7,FPR7,TPR7,ACC7,PPV7]=hyperRoc(rOSP,t);
plot(FPR7,TPR7,'<-')

[AUC8,FPR8,TPR8,ACC8,PPV8]=hyperRoc(rAMSD,t);
plot(FPR8,TPR8,'.-')


[AUC1,FPR1,TPR1,ACC1,PPV1]=hyperRoc(rOSP01,t);
plot(FPR1,TPR1,'<-')

[AUC2,FPR2,TPR2,ACC2,PPV2]=hyperRoc(rAMSD01,t);
plot(FPR2,TPR2,'.-')

[AUC3,FPR3,TPR3,ACC3,PPV3]=hyperRoc(rOSP022,t);
plot(FPR3,TPR3,'<-')

[AUC4,FPR4,TPR4,ACC4,PPV4]=hyperRoc(rAMSD022,t);
plot(FPR4,TPR4,'.-')

[AUC5,FPR5,TPR5,ACC5,PPV5]=hyperRoc(rOSP3,t);
plot(FPR5,TPR5,'<-')

[AUC6,FPR6,TPR6,ACC6,PPV6]=hyperRoc(rAMSD3,t);
plot(FPR6,TPR6,'.-')

arg=[AUC1 ,AUC2 ,AUC3 ,AUC4 ,AUC5 ,AUC6 ,AUC7 ,AUC8 ] ;
xlabel('FPR')
ylabel('TPR')
legend(num2str(arg(1).','OSP + PPI   %d '),num2str(arg(2).','AMSD + PPI   %d '),num2str(arg(3).','OSP + VCA   %d '),num2str(arg(4).','AMSD + VCA   %d '),num2str(arg(5).','OSP + ATGP   %d '),num2str(arg(6).','AMSD + ATGP   %d '),num2str(arg(7).','OSP + Nfinder   %d ',num2str(arg(8).','AMSD + Nfinder   %d ') ,'Location', 'best');
title(sprintf('ROC curve '), 'Interpreter', 'Latex');


hold off
% load('data1.mat')
% sig=M(280,800,:);
% sig=reshape(sig,[1,126]);
% plot(sig')

