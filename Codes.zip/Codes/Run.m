clc
clear

load('data/data1.mat');
[h, w, B] = size(M);
nCol=w;nRow=h;
Y = hyperConvert2d(M);
%[q] = hyperHfcVd(Y, 10^-8);
Y = hyperNormalize( Y );
q=19;
 

%% PPI
fprintf('Performing PPI for endmember determination...\n'); tic;
Uppi = hyperPpi(Y, q, 1000);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

% Plot endmember signatures
figure; plot(Uppi); grid on;
title('PPI Recovered Endmembers', 'Interpreter', 'Latex', 'FontSize', 14);
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
set(ax, 'Interpreter', 'Latex', 'FontSize', 12);
legend(cellstr(num2str((1:q)'))', 'Location', 'EastOutside');

%% N-FINDR
fprintf('Performing N-FINDR for endmember determination...\n'); tic;
Unfindr = hyperNfindr(Y,q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

% Plot endmember signatures
figure; plot(Unfindr); grid on;
title('N-FINDR Recovered Endmembers', 'Interpreter', 'Latex', 'FontSize', 14);
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
set(ax, 'Interpreter', 'Latex', 'FontSize', 12);
legend(cellstr(num2str((1:q)'))', 'Location', 'EastOutside');

%% AVMAX
fprintf('Performing AVMAX for endmember determination...\n'); tic;
Uavmax = hyperAvmax(Y, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

% Plot endmember signatures
figure; plot(Uavmax); grid on;
title('AVMAX Recovered Endmembers', 'Interpreter', 'Latex', 'FontSize', 14);
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
set(ax, 'Interpreter', 'Latex', 'FontSize', 12);
legend(cellstr(num2str((1:q)'))', 'Location', 'EastOutside');

%% AMEE
fprintf('Performing AMEE for endmember determination...\n'); tic;
M=reshape(Y',nCol,nRow,B);
Uamee = hyperAmee(M, q, 5);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

% Plot endmember signatures
figure; plot(Uamee); grid on; ylim([0,1]);
title('AMEE Recovered Endmembers', 'Interpreter', 'Latex', 'FontSize', 14);
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
set(ax, 'Interpreter', 'Latex', 'FontSize', 12);
legend(cellstr(num2str((1:q)'))', 'Location', 'EastOutside');

%% VCA
fprintf('Performing VCA for endmember determination...\n'); tic;
[Uvca, indicies, snrEstimate ] = hyperVca( Y, q );
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

% Plot endmember signatures
figure; plot(Uvca); grid on;
title('VCA Recovered Endmembers', 'Interpreter', 'Latex', 'FontSize', 14);
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
set(ax, 'Interpreter', 'Latex', 'FontSize', 12);
legend(cellstr(num2str((1:q)'))', 'Location', 'EastOutside');

%% compare
vd=1;
figure; grid on;
plot(Uvca(:,vd));hold on;
plot(Uppi(:,vd));
% plot(Uamee(:,vd));
plot(Uavmax(:,6));
plot(Unfindr(:,19))
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
legend('VCA','PPI','AVMAX','N-Finder', 'Location', 'best');
title(sprintf('Endmemder %d th', vd), 'Interpreter', 'Latex');
hold off

%% compare
[errRadiansVca] = hyperSam(Uvca(:,8),Uppi(:,7))
[errRadiansPpi] = hyperSam(Uppi(:,7),Uppi(:,7))
[errRadiansNfindr] = hyperSam(Unfindr(:,13),Uppi(:,7))
arg=[1,errRadiansVca,errRadiansPpi,errRadiansNfindr];
vd=3;
figure; grid on;
% plot(target);hold on;
plot(Uvca(:,8));hold on
plot(Uppi(:,7));
plot(Unfindr(:,13))
ax(1) = ylabel('Reflectance [0-1]'); 
ax(2) = xlabel('Band Number');
legend(num2str(arg(2).','VCA %d radian'),num2str(arg(3).','PPI %d radian'),num2str(arg(4).','N-Finder %d radian'), 'Location', 'best');
title(sprintf('Endmemder %d th', vd), 'Interpreter', 'Latex');
hold off

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Nnls
% Create abundance maps from unmixed endmembers
%% From PPI results:
fprintf('Creating abundance maps from PPI endmember results...\n'); tic;
abundanceMaps = hyperNnls(Y, Uppi);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

fprintf('Plotting and saving PPI abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From N-FINDR results:
fprintf('Creating abundance maps from N-FINDR endmember results...\n'); tic;
abundanceMaps = hyperNnls(Y, Unfindr);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all;
fprintf('Plotting and saving N-FINDR abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AVMAX results:
fprintf('Creating abundance maps from AVMAX endmember results...\n'); tic;
abundanceMaps = hyperNnls(Y, Uavmax);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AVMAX abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AMEE results:
fprintf('Creating abundance maps from AMEE endmember results...\n'); tic;
abundanceMaps = hyperNnls(Y, Uamee);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AMEE abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From VCA results:
fprintf('Creating abundance maps from VCA endmember results...\n'); tic;
abundanceMaps = hyperNnls(Y, Uvca);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving VCA abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% Ucls
% Create abundance maps from unmixed endmembers
%% From PPI results:
fprintf('Creating abundance maps from PPI endmember results...\n'); tic;
abundanceMaps = hyperUcls(Y, Uppi);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

fprintf('Plotting and saving PPI abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From N-FINDR results:
fprintf('Creating abundance maps from N-FINDR endmember results...\n'); tic;
abundanceMaps = hyperUcls(Y, Unfindr);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all;
fprintf('Plotting and saving N-FINDR abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AVMAX results:
fprintf('Creating abundance maps from AVMAX endmember results...\n'); tic;
abundanceMaps = hyperUcls(Y, Uavmax);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AVMAX abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AMEE results:
fprintf('Creating abundance maps from AMEE endmember results...\n'); tic;
abundanceMaps = hyperUcls(Y, Uamee);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AMEE abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From VCA results:
fprintf('Creating abundance maps from VCA endmember results...\n'); tic;
abundanceMaps = hyperUcls(Y, Uvca);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving VCA abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fcls
% Create abundance maps from unmixed endmembers
%% From PPI results:
fprintf('Creating abundance maps from PPI endmember results...\n'); tic;
abundanceMaps = hyperFcls(Y, Uppi);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

fprintf('Plotting and saving PPI abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From N-FINDR results:
fprintf('Creating abundance maps from N-FINDR endmember results...\n'); tic;
abundanceMaps = hyperFcls(Y, Unfindr);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all;
fprintf('Plotting and saving N-FINDR abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AVMAX results:
fprintf('Creating abundance maps from AVMAX endmember results...\n'); tic;
abundanceMaps = hyperFcls(Y, Uavmax);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AVMAX abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From AMEE results:
fprintf('Creating abundance maps from AMEE endmember results...\n'); tic;
abundanceMaps = hyperFcls(Y, Uamee);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving AMEE abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');

%% From VCA results:
fprintf('Creating abundance maps from VCA endmember results...\n'); tic;
abundanceMaps = hyperFcls(Y, Uvca);
abundanceMaps = hyperConvert3d(abundanceMaps, h, w, q);
et=toc; fprintf('...Done. (~%1.3g seconds)\n',et);

close all
fprintf('Plotting and saving VCA abundance maps...\n');
for i=1:q
    figure;clf; imagesc(abundanceMaps(:,:,i)); colorbar; axis image; 
    title(sprintf('Abundance Map %d/%d', i, q), 'Interpreter', 'Latex');
end
fprintf('...Done.\n');