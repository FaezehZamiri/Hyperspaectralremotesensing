clc
clear
close all

t=0.00001;
load('data/data1.mat');
[h, w, B] = size(M);
x=hyperConvert2d(M);
wavlen=1:B;
[B N]=size(x);
noise_type='poisson';

[w Rn] = estNoise(x,noise_type,'on');
[kf Ek]=hysime(x,w,Rn,'on');
nHySime=kf;
disp(' ')

disp('HFC with Error "10^-8"')
nHFC = HFC(x,t);

disp('NWHFC with Error "10^-8"')
nNWHFC = NWHFC(x,t);
         
%          datas = load('CupriteS1_R188.mat');
%          B=datas.nBand;
%          x=datas.Y;
%          wavlen=1:B;
%          SlectBands=datas.SlectBands';
%          BANDS=SlectBands;
%          [B N]=size(x);
%          noise_type='poisson';
%          
%          [w Rn] = estNoise(x,noise_type,verbose);
%          [kf Ek]=hysime(x,w,Rn,verbose);
%          nHySime=kf;
%          disp(' ')
%          disp('HFC with Error "10^-8"')
%          nHFC = HFC(datas.Y,t);
% 
%          disp('NWHFC with Error "10^-8"')
%          nNWHFC = NWHFC(datas.Y,t);
         



