function [varargout]=hysime(varargin);
%
% HySime: Hyperspectral signal subspace estimation
%
% [kf,Ek]=hysime(y,w,Rw,verbose);
%
% Input:
%        y  hyperspectral data set (each column is a pixel)
%           with (L x N), where L is the number of bands
%           and N the number of pixels
%        w  (L x N) matrix with the noise in each pixel
%        Rw noise correlation matrix (L x L)
%        verbose [optional] (on)/off
% Output
%        kf signal subspace dimension
%        Ek matrix which columns are the eigenvectors that span 
%           the signal subspace
%
%  Copyright: Jos� Nascimento (zen@isel.pt)
%             & 
%             Jos� Bioucas-Dias (bioucas@lx.it.pt)
%
%  For any comments contact the authors

error(nargchk(3, 4, nargin))
if nargout > 2, error('too many output parameters'); end
verbose = 1; % default value

y = varargin{1}; % 1st parameter is the data set
[L N] = size(y);
if ~numel(y),error('the data set is empty');end
n = varargin{2}; % the 2nd parameter is the noise
[Ln Nn] = size(n);
Rn = varargin{3}; % the 3rd parameter is the noise correlation matrix
[d1 d2] = size(Rn);
if nargin == 4, verbose = ~strcmp(lower(varargin{4}),'off');end

if Ln~=L | Nn~=N,  % n is an empty matrix or with different size
   error('empty noise matrix or its size does not agree with size of y\n'),
end
if (d1~=d2 | d1~=L)
   Rn = n*n'/N; 
end    


x = y - n;

[L N]=size(y);
Ry = y*y'/N;   % sample correlation matrix 
Rx = x*x'/N;   % signal correlation matrix estimates 
[E,D]=svd(Rx); % eigen values of Rx in decreasing order, equation (15)
dx = diag(D);

Rn=Rn+sum(diag(Rx))/L/10^5*eye(L);

Py = diag(E'*Ry*E); %equation (23)
Pn = diag(E'*Rn*E); %equation (24)
cost_F = -Py + 2 * Pn; %equation (22)
kf = sum(cost_F<0);
[dummy,ind_asc] = sort( cost_F ,'ascend');
Ek = E(:,ind_asc(1:kf));
disp('HiSime')
if verbose,fprintf(1,'The VD number estimated is    %d\n',kf);end

varargout(1) = {kf};
if nargout == 2, varargout(2) = {Ek};end
return

