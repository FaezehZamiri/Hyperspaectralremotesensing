function [AUC,FPR,TPR,ACC,PPV]=hyperRoc(r,t)
X=t(:,1);Y=t(:,2);
numTs = 1000;
pd = linspace(min(r),max(r),numTs);
for ii=1:numTs
    BW = imbinarize(r,pd(ii));
    count=0;
    for i=1:224000
        if BW(i)==1
            count=count+1;
        end
    end
    h=280;w=800;
    BW = hyperConvert3d(BW, h, w, 1);
    BW=double(BW);
    c=0;c2=0;
    for i=1:size(BW,1)
        for j=1:size(BW,2)
            for k=1:size(X,1)
                if i==Y(k) && j==X(k) && BW(i,j)==1
                    c=c+1;
                end
                if i~=Y(k) && j~=X(k) && BW(i,j)==0
                    c2=c2+1;
                end
            end
        end
    end
    TP=c;FN=size(X,1)-c;FP=count-c;TN=c2;
    TPR(ii)=TP/(TP+FN);
    FPR(ii)=FP/(FP+TN);
    ACC(ii)=(TP+TN)/(TP+FP+FN+TN);
    PPV(ii)=TP/(TP+FP);
    AUCs=abs(cumtrapz(FPR,TPR));
    AUC=AUCs(end);
end
